const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const os = require('os');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.static(path.join(__dirname, 'public')));

// ─── Teacher Password ─────────────────────────────────────────────────────────
const TEACHER_PASSWORD = String(Math.floor(10000 + Math.random() * 90000));

// ─── Constants ────────────────────────────────────────────────────────────────
const MAP_W = 50, MAP_H = 50, TILE = 20;
const WORLD_W = MAP_W * TILE, WORLD_H = MAP_H * TILE;

const TANK_SIZE    = 34;
const BULLET_SPEED = 10;
const RESPAWN_TICKS = 300;
const MAX_PER_TEAM  = 25;
const MAX_PLAYERS   = 50;
const TICK_MS       = 33;
const HEAL_RADIUS   = 120;   // px – healer heal range
const HEAL_INTERVAL = 90;    // ticks (~3s)

// ─── Bomb Constants ────────────────────────────────────────────────────────────
const BOMB_INTERVAL_MIN = 3000;   // ms
const BOMB_INTERVAL_MAX = 7000;
const BOMB_WARNING_MS   = 5000;   // warning 표시 시간
const BOMB_RADIUS       = 100;    // 폭발 반경 (px)

const DIR = { UP:0, RIGHT:1, DOWN:2, LEFT:3 };
const DX  = [0, 1, 0, -1];
const DY  = [-1, 0, 1, 0];

const T_EMPTY=0, T_BRICK=1, T_STEEL=2, T_WATER=3, T_BASE_R=4, T_BASE_B=5;

// ─── Role Definitions ─────────────────────────────────────────────────────────
const ROLES = {
  tanker: { maxHp: 10, speed: 3.2,  shootCd: 65, label: '탱커' },
  dealer: { maxHp: 5,  speed: 3.2,  shootCd: 18, label: '딜러' },
  healer: { maxHp: 6,  speed: 2.0,  shootCd: 50, label: '힐러' },
};

// ─── Map Generation ───────────────────────────────────────────────────────────
function buildMap() {
  const m = Array.from({ length: MAP_H }, () => new Array(MAP_W).fill(T_EMPTY));

  // 외곽 철판 테두리
  for (let x=0;x<MAP_W;x++){m[0][x]=T_STEEL;m[MAP_H-1][x]=T_STEEL;}
  for (let y=0;y<MAP_H;y++){m[y][0]=T_STEEL;m[y][MAP_W-1]=T_STEEL;}

  const mid  = Math.floor(MAP_W/2);  // 25
  const midR = Math.floor(MAP_H/2);  // 25

  // 4중 대칭 배치 헬퍼
  function sym(r, c, t) {
    const put = (rr, cc) => { if(rr>=1&&rr<MAP_H-1&&cc>=1&&cc<MAP_W-1) m[rr][cc]=t; };
    put(r, c); put(r, MAP_W-1-c); put(MAP_H-1-r, c); put(MAP_H-1-r, MAP_W-1-c);
  }

  // 벽돌 클러스터 (2×2, 4중 대칭) – 파괴 가능 엄폐물
  const brickSeeds = [
    [4,4], [4,11], [4,18],
    [11,7], [11,14],
    [18,4], [18,11],
  ];
  for (const [r,c] of brickSeeds) {
    for (let dr=0;dr<2;dr++) for (let dc=0;dc<2;dc++) sym(r+dr, c+dc, T_BRICK);
  }

  // 철판 장애물 – 파괴 불가 엄폐물
  // 중앙 좌우 세로 기둥
  for (let r = midR-3; r <= midR+2; r++) {
    sym(r, mid-6, T_STEEL);
  }
  // 상하 중간 가로 철판 블록
  sym(10, mid-3, T_STEEL); sym(10, mid-2, T_STEEL);

  return m;
}

// ─── State ────────────────────────────────────────────────────────────────────
let map = buildMap();
let bullets = {}, bulletId = 0;
let players = {};
let score = { red:0, blue:0 };
let phase = 'lobby';
let winner = null, gameLoop = null, endTimer = null, tick = 0;
let bombTimer = null, bombIdCounter = 0;
let deadRegistry = new Set(); // "name:team" 형태로 게임 중 사망한 플레이어 기록

// 스폰 존: MAP 50×50 기준
const SPAWN_ZONES = {
  red:  Array.from({length:25}, (_,i) => [4 + (i%5)*8, 38 + Math.floor(i/5)]),
  blue: Array.from({length:25}, (_,i) => [4 + (i%5)*8, 4  + Math.floor(i/5)]),
};

function getSpawnPos(team) {
  const used = new Set(Object.values(players).filter(p=>p.team===team).map(p=>`${p.spawnIdx}`));
  const zones = SPAWN_ZONES[team];
  // 사용 안 한 슬롯 중 벽과 겹치지 않는 위치 우선
  for (let i=0;i<zones.length;i++) {
    if (used.has(String(i))) continue;
    const x=zones[i][0]*TILE+TILE, y=zones[i][1]*TILE+TILE;
    if (!rectOverlapsTile(x, y, TANK_SIZE)) return { x, y, idx:i };
  }
  // 모두 사용 중이거나 벽과 겹치면 팀 영역에서 빈 칸 탐색
  return findFreeSpawnInHalf(team);
}

function findFreeSpawnInHalf(team) {
  const rowStart = team==='red' ? Math.floor(MAP_H*0.6) : 1;
  const rowEnd   = team==='red' ? MAP_H-2               : Math.floor(MAP_H*0.4);
  for (let ty=rowStart; ty<=rowEnd; ty++) {
    for (let tx=1; tx<MAP_W-1; tx++) {
      const x=tx*TILE, y=ty*TILE;
      if (!rectOverlapsTile(x, y, TANK_SIZE)) return { x, y, idx: ty * MAP_W + tx + 100 };
    }
  }
  // 최후 폴백
  return { x: TILE*3, y: team==='red'?(WORLD_H-TILE*3):TILE*3, idx:0 };
}

// ─── Collision Helpers ────────────────────────────────────────────────────────
function tileAt(tx, ty) {
  if (tx<0||ty<0||tx>=MAP_W||ty>=MAP_H) return T_STEEL;
  return map[ty][tx];
}
function isSolid(t) {
  return t===T_BRICK||t===T_STEEL||t===T_WATER||t===T_BASE_R||t===T_BASE_B;
}
function rectOverlapsTile(px, py, size) {
  const l=Math.floor(px/TILE), r=Math.floor((px+size-1)/TILE);
  const t2=Math.floor(py/TILE), b=Math.floor((py+size-1)/TILE);
  for (let ty=t2;ty<=b;ty++) for (let tx=l;tx<=r;tx++) if (isSolid(tileAt(tx,ty))) return true;
  return false;
}

// 그리드 스냅: 복도 이동 시 모서리 걸림 방지 (원작 배틀시티 방식)
function snapAxis(v) {
  const nearest = Math.round(v / TILE) * TILE;
  return Math.abs(v - nearest) <= 3 ? nearest : v;
}

function moveTank(p, nx, ny) {
  const movingX = nx !== p.x;
  const movingY = ny !== p.y;

  // X 이동 시도: 성공하면 Y축을 그리드에 스냅 (복도 진입 부드럽게)
  if (movingX) {
    const snapY = snapAxis(p.y);
    if (!rectOverlapsTile(nx, snapY, TANK_SIZE)) {
      p.x = nx;
      p.y = snapY;
    }
  }
  // Y 이동 시도: 성공하면 X축을 그리드에 스냅
  if (movingY) {
    const snapX = snapAxis(p.x);
    if (!rectOverlapsTile(snapX, ny, TANK_SIZE)) {
      p.y = ny;
      p.x = snapX;
    }
  }

  p.x = Math.max(TILE, Math.min(WORLD_W-TILE-TANK_SIZE, p.x));
  p.y = Math.max(TILE, Math.min(WORLD_H-TILE-TANK_SIZE, p.y));

  // 이미 벽 안에 갇혀 있으면 탈출
  if (rectOverlapsTile(p.x, p.y, TANK_SIZE)) {
    pushOutOfWall(p);
  }
}

// 벽에 갇혔을 때 가장 가까운 빈 공간으로 밀어냄
function pushOutOfWall(p) {
  for (let d = 1; d <= TILE * 10; d++) {
    const candidates = [
      [p.x+d, p.y], [p.x-d, p.y],
      [p.x, p.y+d], [p.x, p.y-d],
      [p.x+d, p.y+d], [p.x-d, p.y-d],
      [p.x+d, p.y-d], [p.x-d, p.y+d],
    ];
    for (const [tx, ty] of candidates) {
      const cx = Math.max(TILE, Math.min(WORLD_W-TILE-TANK_SIZE, tx));
      const cy = Math.max(TILE, Math.min(WORLD_H-TILE-TANK_SIZE, ty));
      if (!rectOverlapsTile(cx, cy, TANK_SIZE)) {
        p.x = cx; p.y = cy; return;
      }
    }
  }
}

function bulletHitTiles(bullet) {
  const bx=bullet.x-10/2, by=bullet.y-10/2;
  const l=Math.floor(bx/TILE), r=Math.floor((bx+10)/TILE);
  const t2=Math.floor(by/TILE), b=Math.floor((by+10)/TILE);
  let hit = false;
  for (let ty=t2;ty<=b;ty++) for (let tx=l;tx<=r;tx++) {
    const tile = tileAt(tx,ty);
    if (tile===T_BRICK)  { map[ty][tx]=T_EMPTY; hit=true; }
    else if (tile===T_STEEL||tile===T_BASE_R||tile===T_BASE_B) { hit=true; }
  }
  return hit;
}


function resolvePlayerCollisions() {
  const arr = Object.values(players).filter(p=>p.alive);
  for (let i=0;i<arr.length;i++) for (let j=i+1;j<arr.length;j++) {
    const a=arr[i], b=arr[j];
    const dx=(a.x+TANK_SIZE/2)-(b.x+TANK_SIZE/2);
    const dy=(a.y+TANK_SIZE/2)-(b.y+TANK_SIZE/2);
    const overlap = TANK_SIZE - Math.max(Math.abs(dx), Math.abs(dy));
    if (overlap>0) {
      const push = overlap/2+1;
      if (Math.abs(dx)>Math.abs(dy)) {
        const nx=dx===0?1:Math.sign(dx);
        const naX=a.x+nx*push, nbX=b.x-nx*push;
        // 벽 충돌 체크 후에만 밀기
        if (!rectOverlapsTile(naX, a.y, TANK_SIZE)) a.x=naX;
        if (!rectOverlapsTile(nbX, b.y, TANK_SIZE)) b.x=nbX;
      } else {
        const ny=dy===0?1:Math.sign(dy);
        const naY=a.y+ny*push, nbY=b.y-ny*push;
        if (!rectOverlapsTile(a.x, naY, TANK_SIZE)) a.y=naY;
        if (!rectOverlapsTile(b.x, nbY, TANK_SIZE)) b.y=nbY;
      }
      a.x=Math.max(TILE,Math.min(WORLD_W-TILE-TANK_SIZE,a.x));
      a.y=Math.max(TILE,Math.min(WORLD_H-TILE-TANK_SIZE,a.y));
      b.x=Math.max(TILE,Math.min(WORLD_W-TILE-TANK_SIZE,b.x));
      b.y=Math.max(TILE,Math.min(WORLD_H-TILE-TANK_SIZE,b.y));
    }
  }
}

// ─── Healer Logic ─────────────────────────────────────────────────────────────
function tickHealers() {
  if (phase !== 'playing') return;
  const healers = Object.values(players).filter(p => p.alive && p.role==='healer');
  for (const healer of healers) {
    healer.healTimer = (healer.healTimer || 0) + 1;
    if (healer.healTimer < HEAL_INTERVAL) continue;
    healer.healTimer = 0;

    const healed = [];
    const hcx = healer.x + TANK_SIZE/2, hcy = healer.y + TANK_SIZE/2;
    for (const ally of Object.values(players)) {
      if (!ally.alive || ally.team !== healer.team) continue;
      const acx = ally.x + TANK_SIZE/2, acy = ally.y + TANK_SIZE/2;
      const dist = Math.sqrt((hcx-acx)**2 + (hcy-acy)**2);
      if (dist <= HEAL_RADIUS && ally.hp < ally.maxHp) {
        ally.hp = Math.min(ally.maxHp, ally.hp + 1);
        healed.push({ id: ally.id, hp: ally.hp });
      }
    }
    if (healed.length > 0) {
      io.emit('healEffect', {
        healerId: healer.id,
        hx: healer.x + TANK_SIZE/2,
        hy: healer.y + TANK_SIZE/2,
        radius: HEAL_RADIUS,
        healed
      });
    }
  }
}

// ─── Game Tick ────────────────────────────────────────────────────────────────
function gameTick() {
  tick++;
  const changedTiles = [];

  // 플레이어 목록 1회 캐싱 (Object.values 반복 호출 방지)
  const allPlayers = Object.values(players);

  for (const p of allPlayers) {
    if (!p.alive) continue;
    if (p.shootCd>0) p.shootCd--;
    if (p.moving && p.dir!==null) moveTank(p, p.x+DX[p.dir]*p.speed, p.y+DY[p.dir]*p.speed);
    if (p.shield>0) p.shield--;
  }

  if (phase==='playing') resolvePlayerCollisions();
  tickHealers();

  const dead = new Set();
  const snap = map.map(r=>[...r]);
  for (const [bid, b] of Object.entries(bullets)) {
    if (dead.has(bid)) continue;
    b.x += DX[b.dir]*BULLET_SPEED;
    b.y += DY[b.dir]*BULLET_SPEED;

    if (b.x<TILE||b.y<TILE||b.x>WORLD_W-TILE||b.y>WORLD_H-TILE) { dead.add(bid); continue; }

    if (bulletHitTiles(b)) {
      dead.add(bid);
      for (let ty=0;ty<MAP_H;ty++) for (let tx=0;tx<MAP_W;tx++)
        if (map[ty][tx]!==snap[ty][tx]) changedTiles.push({tx,ty,t:map[ty][tx]});
      continue;
    }

    let hitBullet=false;
    for (const [bid2,b2] of Object.entries(bullets)) {
      if (bid===bid2||dead.has(bid2)) continue;
      if (Math.abs(b.x-b2.x)<8&&Math.abs(b.y-b2.y)<8) { dead.add(bid);dead.add(bid2);hitBullet=true;break; }
    }
    if (hitBullet) continue;

    for (const p of allPlayers) {
      if (!p.alive||p.id===b.ownerId||p.team===b.team||p.shield>0) continue;
      const cx=p.x+TANK_SIZE/2, cy=p.y+TANK_SIZE/2;
      if (Math.abs(b.x-cx)<TANK_SIZE/2+4 && Math.abs(b.y-cy)<TANK_SIZE/2+4) {
        damagePlayer(p, b.ownerId);
        dead.add(bid); break;
      }
    }
  }
  for (const bid of dead) delete bullets[bid];

  const state = buildSlimState();
  if (changedTiles.length>0) state.tiles = changedTiles;
  io.volatile.emit('gameUpdate', state);
}

function damagePlayer(victim, attackerId) {
  victim.hp -= 1;
  io.emit('playerDamaged', { id: victim.id, hp: victim.hp, maxHp: victim.maxHp });
  if (victim.hp <= 0) killPlayer(victim, attackerId);
}

function buildSlimState() {
  const ps = {};
  for (const [id,p] of Object.entries(players))
    ps[id] = { x:p.x, y:p.y, dir:p.dir, alive:p.alive,
               respawnTimer:p.respawnTimer, shield:p.shield,
               hp:p.hp, kills:p.kills, deaths:p.deaths };
  const bs = {};
  for (const [id,b] of Object.entries(bullets))
    bs[id] = { x:b.x, y:b.y, dir:b.dir, team:b.team, role:b.role };
  return { players:ps, bullets:bs, score, tick };
}

function buildFullPlayerState() {
  const ps = {};
  for (const [id,p] of Object.entries(players))
    ps[id] = { id:p.id, name:p.name, team:p.team, role:p.role, isTeacher:p.isTeacher,
               x:p.x, y:p.y, dir:p.dir, alive:p.alive,
               hp:p.hp, maxHp:p.maxHp, kills:p.kills, deaths:p.deaths, shield:p.shield };
  return ps;
}

function broadcastLobbyUpdate() {
  io.emit('lobbyUpdate', { players: buildFullPlayerState(), phase });
}

// ─── Bomb System ──────────────────────────────────────────────────────────────
function scheduleBomb() {
  const delay = BOMB_INTERVAL_MIN + Math.random() * (BOMB_INTERVAL_MAX - BOMB_INTERVAL_MIN);
  bombTimer = setTimeout(() => {
    if (phase !== 'playing') return;
    triggerBomb();
    scheduleBomb();
  }, delay);
}

function triggerBomb() {
  const elapsedSec = tick * TICK_MS / 1000;
  const extra  = Math.floor(elapsedSec / 15); // 15초마다 +1
  const count  = Math.min(20, 6 + extra + Math.floor(Math.random() * 5)); // 최대 20개
  const margin = TILE * 4;
  for (let i = 0; i < count; i++) {
    const stagger = i * 200; // 200ms 간격으로 순차 투하
    setTimeout(() => {
      if (phase !== 'playing') return;
      const x = Math.round(margin + Math.random() * (WORLD_W - margin * 2));
      const y = Math.round(margin + Math.random() * (WORLD_H - margin * 2));
      const id = ++bombIdCounter;
      io.emit('bombWarning', { id, x, y, radius: BOMB_RADIUS, countdown: BOMB_WARNING_MS });
      setTimeout(() => {
        if (phase !== 'playing') return;
        io.emit('bombStrike', { id, x, y, radius: BOMB_RADIUS });
        for (const p of Object.values(players)) {
          if (!p.alive) continue;
          const cx = p.x + TANK_SIZE/2, cy = p.y + TANK_SIZE/2;
          if ((cx-x)**2 + (cy-y)**2 <= (BOMB_RADIUS + TANK_SIZE/2)**2) {
            killPlayer(p, null);
          }
        }
      }, BOMB_WARNING_MS);
    }, stagger);
  }
}

function startGame() {
  phase = 'countdown';
  deadRegistry.clear();
  for (const p of Object.values(players)) {
    const sp = getSpawnPos(p.team);
    p.x=sp.x; p.y=sp.y; p.spawnIdx=sp.idx;
    p.alive=true; p.hp=p.maxHp; p.shield=120; p.respawnTimer=0;
    p.dir = p.team==='red' ? DIR.UP : DIR.DOWN;
    p.healTimer=0;
  }
  io.emit('gameStart', { map, players: buildFullPlayerState(), score });

  // 3초 카운트다운 후 실제 게임 시작
  let count = 3;
  io.emit('countdown', { count });
  const cdInterval = setInterval(() => {
    count--;
    if (count > 0) {
      io.emit('countdown', { count });
    } else {
      clearInterval(cdInterval);
      phase = 'playing';
      io.emit('countdownDone');
      if (!gameLoop) gameLoop = setInterval(gameTick, TICK_MS);
      scheduleBomb();
    }
  }, 1000);
}

function respawnPlayer(p) {
  const sp = getSpawnPos(p.team);
  p.x=sp.x; p.y=sp.y; p.spawnIdx=sp.idx;
  p.alive=true; p.hp=p.maxHp; p.respawnTimer=0; p.shield=120;
  p.dir = p.team==='red' ? DIR.UP : DIR.DOWN;
  p.healTimer=0;
  io.emit('playerRespawn', { id:p.id, x:p.x, y:p.y, hp:p.hp, maxHp:p.maxHp, shield:p.shield });
}

function killPlayer(victim, killerId) {
  victim.alive=false; victim.hp=0; victim.deaths++;
  victim.respawnTimer=0;
  deadRegistry.add(`${victim.name}:${victim.team}`);
  const killer = killerId ? players[killerId] : null;
  if (killer) { killer.kills++; score[killer.team]++; }
  const killerName = killer ? killer.name : (killerId ? '?' : '💣 폭격');
  io.emit('playerKilled', {
    victimId:victim.id, killerId,
    killerName, victimName:victim.name, score
  });
  // 팀 전멸 체크 → 게임 오버 (생존 승리 조건)
  if (phase==='playing') {
    const teamAlive = Object.values(players).filter(p=>p.team===victim.team&&p.alive);
    if (teamAlive.length===0) {
      phase='ended';
      winner = victim.team==='red'?'blue':'red';
      clearTimeout(bombTimer); bombTimer=null;
      io.emit('gameOver',{ winner, score, reason:`${victim.team==='red'?'레드':'블루'}팀 전멸! 최후의 생존팀 승리!` });
      clearInterval(gameLoop); gameLoop=null;
      endTimer = setTimeout(resetGame, 10000);
    }
  }
}

function resetGame() {
  clearInterval(gameLoop); gameLoop=null;
  clearTimeout(endTimer); endTimer=null;
  clearTimeout(bombTimer); bombTimer=null;
  map=buildMap(); bullets={}; bulletId=0;
  score={red:0,blue:0}; phase='lobby'; winner=null; tick=0;
  deadRegistry.clear();
  for (const p of Object.values(players)) {
    const sp = getSpawnPos(p.team);
    p.x=sp.x; p.y=sp.y; p.spawnIdx=sp.idx;
    p.alive=true; p.hp=p.maxHp; p.respawnTimer=0; p.kills=0; p.deaths=0;
    p.shield=0; p.shootCd=0; p.moving=false; p.healTimer=0;
    p.dir = p.team==='red' ? DIR.UP : DIR.DOWN;
  }
  io.emit('gameReset', { map, players: buildFullPlayerState(), score });
}

// ─── Socket.IO ────────────────────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[+] connect ${socket.id}`);

  socket.on('joinGame', ({ name, team, role, password }) => {
    if (phase !== 'lobby') {
      socket.emit('joinError', '게임이 진행 중입니다. 다음 게임을 기다려주세요.'); return;
    }
    if (Object.keys(players).length >= MAX_PLAYERS) {
      socket.emit('joinError', '서버가 가득 찼습니다 (최대 50명).'); return;
    }
    const isTeacher = (password === TEACHER_PASSWORD);
    if (password && !isTeacher) {
      socket.emit('joinError', '선생님 비밀번호가 틀렸습니다.'); return;
    }

    const validRoles = ['tanker','dealer','healer'];
    const r = validRoles.includes(role) ? role : 'dealer';
    const roleStats = ROLES[r];

    // 팀 배정: 선생님은 선택 팀 / 학생은 자동 균형 배정
    let t;
    if (isTeacher) {
      t = (team==='red'||team==='blue') ? team : 'red';
      if (Object.values(players).filter(p=>p.team===t).length >= MAX_PER_TEAM)
        t = t==='red'?'blue':'red';
    } else {
      const reds  = Object.values(players).filter(p=>p.team==='red').length;
      const blues = Object.values(players).filter(p=>p.team==='blue').length;
      t = reds <= blues ? 'red' : 'blue';
      if (Object.values(players).filter(p=>p.team===t).length >= MAX_PER_TEAM)
        t = t==='red'?'blue':'red';
    }

    const playerName = (name||'탱크').slice(0,12);

    const sp = getSpawnPos(t);
    const p = {
      id: socket.id,
      name: playerName,
      team: t, role: r, isTeacher,
      x:sp.x, y:sp.y, spawnIdx:sp.idx,
      dir: t==='red' ? DIR.UP : DIR.DOWN,
      alive:true, hp:roleStats.maxHp, maxHp:roleStats.maxHp,
      speed:roleStats.speed, shootCd:0, maxShootCd:roleStats.shootCd,
      shield:0, moving:false, kills:0, deaths:0, respawnTimer:0, healTimer:0
    };
    players[socket.id] = p;

    socket.emit('joinedGame', {
      id:socket.id, team:t, role:r, isTeacher, map,
      players:buildFullPlayerState(), score, phase
    });
    socket.broadcast.emit('playerJoined', {
      id:socket.id, name:p.name, team:t, role:r, isTeacher,
      x:p.x, y:p.y, dir:p.dir, alive:true,
      hp:p.hp, maxHp:p.maxHp, kills:0, deaths:0, shield:0
    });
    console.log(`  [join] ${p.name} (${t}/${r})${isTeacher?' 👑':''} | 총 ${Object.keys(players).length}명`);
  });

  socket.on('startGame', () => {
    const p = players[socket.id];
    if (!p||!p.isTeacher||phase!=='lobby') return;
    const reds  = Object.values(players).filter(p=>p.team==='red').length;
    const blues = Object.values(players).filter(p=>p.team==='blue').length;
    if (reds<1||blues<1) { socket.emit('startError','양쪽 팀에 최소 1명씩 있어야 합니다.'); return; }
    startGame();
  });

  socket.on('setPlayerTeam', ({ targetId, team }) => {
    const me = players[socket.id];
    if (!me||!me.isTeacher||phase!=='lobby') return;
    const target = players[targetId];
    if (!target||target.team===team) return;
    const cnt = Object.values(players).filter(p=>p.team===team).length;
    if (cnt>=MAX_PER_TEAM) { socket.emit('setTeamError',`${team==='red'?'레드':'블루'}팀이 가득 찼습니다.`); return; }
    target.team = team;
    target.dir  = team==='red' ? DIR.UP : DIR.DOWN;
    if (phase==='lobby') {
      const sp = getSpawnPos(team); target.x=sp.x; target.y=sp.y; target.spawnIdx=sp.idx;
    }
    io.to(targetId).emit('teamChanged', { team });
    broadcastLobbyUpdate();
  });

  socket.on('resetGame', () => {
    const p = players[socket.id];
    if (!p||!p.isTeacher) return;
    resetGame();
  });

  socket.on('playerMove', ({ dir, moving }) => {
    const p = players[socket.id];
    if (!p||!p.alive) return;
    if (dir!==undefined&&dir!==null) p.dir=dir;
    p.moving=moving;
  });

  socket.on('playerShoot', () => {
    const p = players[socket.id];
    if (!p||!p.alive||p.shootCd>0||phase!=='playing') return;
    // 플레이어당 동시 총알 1개 제한 (원작 배틀시티 룰 + 50인 성능 보호)
    const hasActive = Object.values(bullets).some(b=>b.ownerId===socket.id);
    if (hasActive) return;
    p.shootCd = p.maxShootCd;
    const bid = `b${++bulletId}`;
    const cx = p.x+TANK_SIZE/2, cy = p.y+TANK_SIZE/2;
    bullets[bid] = { id:bid, ownerId:socket.id, team:p.team, role:p.role, x:cx, y:cy, dir:p.dir };
    io.emit('bulletFired', { id:bid, x:cx, y:cy, dir:p.dir, team:p.team, role:p.role });
  });

  socket.on('disconnect', () => {
    const p = players[socket.id];
    if (p) { console.log(`[-] disconnect ${p.name}`); io.emit('playerLeft',{id:socket.id}); delete players[socket.id]; }
    if (Object.keys(players).length===0) {
      clearInterval(gameLoop); gameLoop=null; clearTimeout(endTimer); endTimer=null;
      phase='lobby'; map=buildMap(); bullets={}; score={red:0,blue:0}; tick=0;
      io.emit('gameReset', { map, players:{}, score });
    }
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = 3000;
server.listen(PORT, () => {
  let localIP = 'localhost';
  try {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces))
      for (const iface of ifaces[name])
        if (iface.family==='IPv4'&&!iface.internal) { localIP=iface.address; break; }
  } catch(e) {}

  const line = '═'.repeat(46);
  console.log(`\n  ${line}`);
  console.log(`    🎮  BATTLE CITY ONLINE`);
  console.log(`  ${line}`);
  console.log(`    서버 주소      : http://localhost:${PORT}`);
  console.log(`    네트워크 주소  : http://${localIP}:${PORT}`);
  console.log(`    선생님 비밀번호: ${TEACHER_PASSWORD}`);
  console.log(`    역할군         : 탱커 / 딜러 / 힐러`);
  console.log(`    팀 구성        : 레드 vs 블루 | 최대 ${MAX_PLAYERS}명`);
  console.log(`  ${line}\n`);
});

module.exports = { server, io };
