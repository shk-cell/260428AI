# 🐍 SLITHER.IO — 실제 멀티플레이어

## 📁 파일 구조

slither-multi/
├── server.js     ← Node.js 게임 서버 (WebSocket)
├── index.html    ← 클라이언트 (브라우저)
├── package.json
└── README.md
```

## 🚀 실행 방법


### 1. 의존성 설치
npm install

### 2. 서버 시작

node server.js

### 3. 클라우드페어 터널 

다른 터미널 열고 
npx cloudflared tunnel --url http://localhost:3000

나오는 사이트 복붙해서 접속하면 완료!

