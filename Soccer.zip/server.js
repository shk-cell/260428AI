const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// CONSTANTS (must match client-side constants in index.html)
// ============================================================
const FIELD = { x: 150, y: 150, w: 3600, h: 2200 }; // large world field
const GOAL  = { y1: 1100, y2: 1400, depth: 55 };    // center=1250 (FIELD.y+FIELD.h/2=1250), height=300px

const PLAYER_RADIUS    = 22;
const BALL_RADIUS      = 14;
const PLAYER_SPEED     = 6.0;
const SHOOT_SPEED      = 48;
const PASS_SPEED       = 28;
const BALL_FRICTION    = 0.984;
const BALL_STOP        = 0.2;
const POSSESS_RANGE    = 32;   // px: ball pickup range (loose ball or opponent steal)
const POSSESS_RANGE_SQ = POSSESS_RANGE * POSSESS_RANGE;
const RELEASE_CD       = 20;   // ticks before kicker/loser can re-possess
const GAME_DURATION    = 300;  // seconds
const GOAL_PAUSE       = 3.2;  // seconds to pause after goal
const TICK_MS          = 16;   // ~62.5 fps
const SEND_EVERY       = 2;    // broadcast state every 2 ticks (~31 fps) — reduces WiFi load
const DIAG             = 1 / Math.SQRT2;  // 0.7071… — normalise diagonal movement without sqrt

// ============================================================
// TEACHER PASSWORD
// ============================================================
const TEACHER_PWD = Array.from({ length: 5 }, () => Math.floor(Math.random() * 10)).join('');
console.log('\n==============================');
console.log('  ⚽ Soccer Game Server');
console.log(`  Teacher Password : ${TEACHER_PWD}`);
console.log('  Port             : 3000');
console.log('==============================\n');

// ============================================================
// ROOMS
// ============================================================
const rooms = {};

function genCode() {
  const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from({ length: 5 }, () => c[Math.floor(Math.random() * c.length)]).join('');
}

function autoTeam(room) {
  let r = 0, b = 0;
  for (const p of Object.values(room.players)) {
    if (p.team === 'red') r++; else b++;
  }
  return r <= b ? 'red' : 'blue';
}

function getLobbyData(room) {
  return {
    code: room.code,
    teacherName: room.teacherName,
    players: Object.entries(room.players).map(([id, p]) => ({
      id, name: p.name, team: p.team, isTeacher: p.isTeacher,
    })),
  };
}

// ============================================================
// GAME STATE CREATION
// ============================================================
function createGameState(room) {
  const teamPlayers = { red: [], blue: [] };
  for (const [id, p] of Object.entries(room.players)) {
    teamPlayers[p.team].push({ id, name: p.name, team: p.team });
  }

  const cx = FIELD.x + FIELD.w / 2;
  const cy = FIELD.y + FIELD.h / 2;
  const players = {};

  for (const team of ['red', 'blue']) {
    const list = teamPlayers[team];
    const count = list.length;
    const baseX  = team === 'red' ? cx - 600 : cx + 600;
    const spacing = Math.max(PLAYER_RADIUS * 2 + 6, Math.min(90, (FIELD.h - 100) / Math.max(count, 1)));
    const startY  = cy - spacing * (count - 1) / 2;

    list.forEach((p, i) => {
      // Clamp spawn position inside field boundaries (handles 25+ players on one team)
      const rawY = startY + i * spacing + (Math.random() - 0.5) * 8;
      const clampedX = Math.max(FIELD.x + PLAYER_RADIUS + 5, Math.min(FIELD.x + FIELD.w - PLAYER_RADIUS - 5,
        baseX + (Math.random() - 0.5) * 30));
      const clampedY = Math.max(FIELD.y + PLAYER_RADIUS + 5, Math.min(FIELD.y + FIELD.h - PLAYER_RADIUS - 5, rawY));
      players[p.id] = {
        id: p.id, name: p.name, team,
        x: clampedX, y: clampedY,
        dx: 0, dy: 0,
        facingX: team === 'red' ? 1 : -1, facingY: 0,
        hasBall: false,
        releaseCd: 0,
      };
    });
  }

  const ballCount = room.ballCount || 1;
  const balls = Array.from({ length: ballCount }, (_, i) => {
    const angle = ballCount > 1 ? (i / ballCount) * Math.PI * 2 : 0;
    const spread = ballCount > 1 ? 120 : 0;
    return { x: cx + Math.cos(angle) * spread, y: cy + Math.sin(angle) * spread, vx: 0, vy: 0, owner: null, lastToucherId: null };
  });

  const gs = {
    players,
    balls,
    score: { red: 0, blue: 0 },
    timeLeft: GAME_DURATION,
    phase: 'playing',   // 'playing' | 'goal' | 'ended'
    goalTimer: 0,
    lastGoal: null,
    lastToucherId: null,
    tick: 0,
  };
  gs.playerList = Object.values(gs.players); // cached — avoids Object.values() every tick
  return gs;
}

function resetForKickoff(gs) {
  const cx = FIELD.x + FIELD.w / 2;
  const cy = FIELD.y + FIELD.h / 2;

  const ballCount = gs.balls.length;
  gs.balls = Array.from({ length: ballCount }, (_, i) => {
    const angle = ballCount > 1 ? (i / ballCount) * Math.PI * 2 : 0;
    const spread = ballCount > 1 ? 120 : 0;
    return { x: cx + Math.cos(angle) * spread, y: cy + Math.sin(angle) * spread, vx: 0, vy: 0, owner: null, lastToucherId: null };
  });

  for (const p of gs.playerList) {
    p.dx = 0; p.dy = 0;
    p.hasBall = false;
    p.releaseCd = 0;
    // Push each player into their own half with random position
    const halfW = FIELD.w / 2 - 20;
    const baseX = p.team === 'red'
      ? FIELD.x + FIELD.w / 4
      : FIELD.x + FIELD.w * 3 / 4;
    p.x = baseX + (Math.random() - 0.5) * halfW * 0.7;
    p.y = cy  + (Math.random() - 0.5) * (FIELD.h - 80);
    p.x = Math.max(FIELD.x + PLAYER_RADIUS + 5, Math.min(FIELD.x + FIELD.w - PLAYER_RADIUS - 5, p.x));
    p.y = Math.max(FIELD.y + PLAYER_RADIUS + 5, Math.min(FIELD.y + FIELD.h - PLAYER_RADIUS - 5, p.y));
    p.facingX = p.team === 'red' ? 1 : -1;
    p.facingY = 0;
  }
  gs.phase = 'playing';
}

// ============================================================
// HELPERS
// ============================================================
function norm(x, y) {
  const len = Math.sqrt(x * x + y * y);
  return len === 0 ? { x: 0, y: 0 } : { x: x / len, y: y / len };
}
// distSq: squared distance (no sqrt) — use for threshold comparisons
function distSq(a, b) { const dx = a.x - b.x, dy = a.y - b.y; return dx * dx + dy * dy; }
function dist(a, b)   { return Math.sqrt(distSq(a, b)); }

// Full state — sent once on gameStart (includes static name/team)
function packState(gs) {
  const ownerSet = new Set(gs.balls.map(b => b.owner).filter(Boolean));
  return {
    players: gs.playerList.map(p => ({
      id: p.id, name: p.name, team: p.team,
      x: Math.round(p.x * 2) / 2, y: Math.round(p.y * 2) / 2,
      fx: p.facingX, fy: p.facingY, hasBall: ownerSet.has(p.id),
    })),
    balls: gs.balls.map(b => ({ x: Math.round(b.x * 2) / 2, y: Math.round(b.y * 2) / 2, owner: b.owner })),
    score: gs.score, timeLeft: Math.ceil(gs.timeLeft), phase: gs.phase,
  };
}

// Slim update — sent at 62 fps (omits static name/team to reduce payload ~30%)
function packUpdate(gs) {
  const ownerSet = new Set(gs.balls.map(b => b.owner).filter(Boolean));
  return {
    players: gs.playerList.map(p => ({
      id: p.id,
      x: Math.round(p.x * 2) / 2, y: Math.round(p.y * 2) / 2,
      fx: p.facingX, fy: p.facingY, hasBall: ownerSet.has(p.id),
    })),
    balls: gs.balls.map(b => ({ x: Math.round(b.x * 2) / 2, y: Math.round(b.y * 2) / 2, owner: b.owner })),
    score: gs.score, timeLeft: Math.ceil(gs.timeLeft), phase: gs.phase,
  };
}

// ============================================================
// GAME LOOP  (drift-compensating setInterval replacement)
// ============================================================
// Node.js setInterval drifts over time. This wrapper tracks cumulative
// drift and fires early/late to stay accurate on average.
function stopGameLoop(handle) {
  if (!handle) return;
  handle.active = false;
  if (handle.id != null) clearTimeout(handle.id);
}

function startGameLoop(room) {
  let expected = Date.now() + TICK_MS;
  const handle = { id: null, active: true };

  function step() {
    if (!handle.active) return;
    tickGame(room);
    const now  = Date.now();
    const drift = now - expected;          // positive = we're running late
    expected   += TICK_MS;
    const next  = Math.max(0, TICK_MS - drift);
    handle.id   = setTimeout(step, next);
  }

  handle.id = setTimeout(step, TICK_MS);
  return handle;
}

// ============================================================
// GAME TICK  (physics simulation)
// ============================================================
function tickGame(room) {
  const gs = room.gameState;
  if (!gs || gs.phase === 'ended') return;
  gs.tick++;

  // ---- GOAL PAUSE PHASE ----
  if (gs.phase === 'goal') {
    gs.goalTimer -= TICK_MS / 1000;
    if (gs.goalTimer <= 0) {
      resetForKickoff(gs);
      io.to(room.code).emit('kickoff');
    }
    if (gs.tick % SEND_EVERY === 0) io.to(room.code).volatile.emit('gameUpdate', packUpdate(gs));
    return;
  }

  // ---- TIMER ----
  gs.timeLeft -= TICK_MS / 1000;
  if (gs.timeLeft <= 0) {
    gs.timeLeft = 0;
    gs.phase = 'ended';
    stopGameLoop(room.gameLoop);
    room.gameLoop = null;
    const { red, blue } = gs.score;
    const winner = red > blue ? 'red' : blue > red ? 'blue' : 'draw';
    io.to(room.code).emit('gameOver', { score: gs.score, winner });
    return;
  }

  const pList = gs.playerList; // cached array — no allocation per tick

  // ---- MOVE PLAYERS ----
  for (const p of pList) {
    if (p.releaseCd > 0) p.releaseCd--;

    if (p.dx !== 0 || p.dy !== 0) {
      // Inline normalisation: diagonal = 1/√2 × speed, cardinal = full speed (no sqrt, no object)
      const spd = (p.dx !== 0 && p.dy !== 0) ? PLAYER_SPEED * DIAG : PLAYER_SPEED;
      p.x += p.dx * spd;
      p.y += p.dy * spd;
      p.facingX = p.dx;
      p.facingY = p.dy;
    }
    p.x = Math.max(FIELD.x + PLAYER_RADIUS, Math.min(FIELD.x + FIELD.w - PLAYER_RADIUS, p.x));
    p.y = Math.max(FIELD.y + PLAYER_RADIUS, Math.min(FIELD.y + FIELD.h - PLAYER_RADIUS, p.y));
  }

  // ---- PLAYER-PLAYER COLLISION (adaptive passes: fewer players = fewer passes) ----
  const minD  = PLAYER_RADIUS * 2;
  const minD2 = minD * minD;
  const passes = pList.length < 8 ? 1 : pList.length < 14 ? 2 : 3;
  for (let pass = 0; pass < passes; pass++) {
    for (let i = 0; i < pList.length; i++) {
      for (let j = i + 1; j < pList.length; j++) {
        const a = pList[i], b = pList[j];
        const dx = b.x - a.x, dy = b.y - a.y;
        // Cheap squared-distance early-out (avoids sqrt for non-colliding pairs)
        if (dx * dx + dy * dy >= minD2) continue;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < 0.01) continue;
        const push = (minD - d) / 2;
        const nx = dx / d, ny = dy / d;
        a.x -= nx * push; a.y -= ny * push;
        b.x += nx * push; b.y += ny * push;
      }
    }
  }
  // Re-clamp after collision resolution (players near walls may be pushed outside)
  for (const p of pList) {
    p.x = Math.max(FIELD.x + PLAYER_RADIUS, Math.min(FIELD.x + FIELD.w - PLAYER_RADIUS, p.x));
    p.y = Math.max(FIELD.y + PLAYER_RADIUS, Math.min(FIELD.y + FIELD.h - PLAYER_RADIUS, p.y));
  }

  // ---- BALL PHYSICS (each ball independently) ----
  for (const ball of gs.balls) {
    if (ball.owner) {
      const owner = gs.players[ball.owner];
      if (!owner) {
        ball.owner = null;
      } else {
        // Ball sticks just in front of player
        const fx = owner.facingX, fy = owner.facingY;
        if (fx === 0 && fy === 0) {
          ball.x = owner.x; ball.y = owner.y - PLAYER_RADIUS - BALL_RADIUS;
        } else {
          const step = (PLAYER_RADIUS + BALL_RADIUS + 1) * ((fx !== 0 && fy !== 0) ? DIAG : 1);
          ball.x = owner.x + fx * step;
          ball.y = owner.y + fy * step;
        }
        ball.vx = 0; ball.vy = 0;

        // ---- INSTANT STEAL: opponent touches the ball ----
        if (owner.releaseCd === 0) {
          for (const p of pList) {
            if (p.team === owner.team) continue;
            if (distSq(p, ball) <= POSSESS_RANGE_SQ) {
              owner.releaseCd = RELEASE_CD;
              ball.owner = p.id;
              ball.lastToucherId = p.id;
              break;
            }
          }
        }
      }
    } else {
      // Free ball
      ball.x += ball.vx;
      ball.y += ball.vy;
      ball.vx *= BALL_FRICTION;
      ball.vy *= BALL_FRICTION;
      if (Math.abs(ball.vx) < BALL_STOP) ball.vx = 0;
      if (Math.abs(ball.vy) < BALL_STOP) ball.vy = 0;

      // ---- TOP/BOTTOM WALLS ----
      if (ball.y - BALL_RADIUS < FIELD.y) {
        ball.y = FIELD.y + BALL_RADIUS;
        ball.vy = Math.abs(ball.vy) * 0.65;
      }
      if (ball.y + BALL_RADIUS > FIELD.y + FIELD.h) {
        ball.y = FIELD.y + FIELD.h - BALL_RADIUS;
        ball.vy = -Math.abs(ball.vy) * 0.65;
      }

      // ---- LEFT WALL / GOAL ----
      if (ball.x - BALL_RADIUS < FIELD.x) {
        if (ball.y >= GOAL.y1 && ball.y <= GOAL.y2) {
          handleGoal(room, gs, 'blue', ball);
          return;
        }
        ball.x = FIELD.x + BALL_RADIUS;
        ball.vx = Math.abs(ball.vx) * 0.7;
      }

      // ---- RIGHT WALL / GOAL ----
      if (ball.x + BALL_RADIUS > FIELD.x + FIELD.w) {
        if (ball.y >= GOAL.y1 && ball.y <= GOAL.y2) {
          handleGoal(room, gs, 'red', ball);
          return;
        }
        ball.x = FIELD.x + FIELD.w - BALL_RADIUS;
        ball.vx = -Math.abs(ball.vx) * 0.7;
      }

      // ---- POSSESSION CHECK (only within field) ----
      if (ball.x >= FIELD.x && ball.x <= FIELD.x + FIELD.w) {
        const ballOwners = new Set(gs.balls.map(b => b.owner).filter(Boolean));
        let nearest = null, nearestDSq = POSSESS_RANGE_SQ;
        for (const p of pList) {
          if (p.releaseCd > 0) continue;
          if (ballOwners.has(p.id)) continue; // 이미 공 소유 중이면 제외
          const dq = distSq(p, ball);
          if (dq < nearestDSq) { nearestDSq = dq; nearest = p; }
        }
        if (nearest) {
          ball.owner = nearest.id;
          ball.vx = 0; ball.vy = 0;
          ball.lastToucherId = nearest.id;
        }
      }
    }
  }

  // ---- BROADCAST ----
  if (gs.tick % SEND_EVERY === 0) {
    io.to(room.code).volatile.emit('gameUpdate', packUpdate(gs));
  }
}

function handleGoal(room, gs, scoringTeam, ball) {
  gs.score[scoringTeam]++;
  gs.phase = 'goal';
  gs.goalTimer = GOAL_PAUSE;
  gs.lastGoal = scoringTeam;
  // 득점 공의 lastToucherId로 득점자 판별
  const scorer = ball.lastToucherId ? gs.players[ball.lastToucherId] : null;
  const scorerName = scorer ? scorer.name : null;
  // Freeze all balls & clear possession
  for (const b of gs.balls) { b.vx = 0; b.vy = 0; b.owner = null; }
  for (const p of gs.playerList) { p.hasBall = false; p.dx = 0; p.dy = 0; }
  io.to(room.code).emit('goal', { team: scoringTeam, score: gs.score, scorerName });
}

// ============================================================
// PLAYER CLEANUP (extracted so disconnect can defer it with a grace period)
// ============================================================
function cleanupPlayer(code, socketId) {
  const room = rooms[code];
  if (!room) return;

  delete room.players[socketId];

  if (room.gameState) {
    const p = room.gameState.players[socketId];
    if (p) {
      for (const b of room.gameState.balls) {
        if (b.owner === socketId) { b.owner = null; b.vx = 0; b.vy = 0; }
      }
      // Clear lastToucherId if disconnecting player was last toucher
      if (room.gameState.lastToucherId === socketId) {
        room.gameState.lastToucherId = null;
      }
      delete room.gameState.players[socketId];
      const idx = room.gameState.playerList.findIndex(q => q.id === socketId);
      if (idx !== -1) room.gameState.playerList.splice(idx, 1);
    }
  }

  if (Object.keys(room.players).length === 0) {
    if (room.countdownTimer) clearInterval(room.countdownTimer);
    if (room.gameLoop)       stopGameLoop(room.gameLoop);
    delete rooms[code];
  } else {
    io.to(code).emit('lobbyUpdate', getLobbyData(room));
  }
}

// ============================================================
// SOCKET HANDLERS
// ============================================================
io.on('connection', (socket) => {

  socket.on('getRooms', () => {
    const list = Object.values(rooms)
      .filter(r => !r.started)
      .map(r => ({ code: r.code, teacherName: r.teacherName, players: Object.keys(r.players).length }));
    socket.emit('roomList', list);
  });

  socket.on('createRoom', ({ name, password, token }) => {
    if (password !== TEACHER_PWD) { socket.emit('err', '비밀번호가 틀렸습니다'); return; }
    const code = genCode();
    rooms[code] = {
      code, teacher: socket.id, teacherName: name,
      players: { [socket.id]: { name, team: 'red', isTeacher: true, token: token || null } },
      started: false, gameState: null, gameLoop: null, countdownTimer: null,
      _pendingDisconnects: {},
    };
    socket.join(code);
    socket.roomCode = code;
    socket.isTeacher = true;
    socket.emit('roomCreated', { code });
    socket.emit('lobbyUpdate', getLobbyData(rooms[code]));
  });

  socket.on('joinRoom', ({ code, name, token }) => {
    code = code.toUpperCase().trim();
    const room = rooms[code];
    if (!room)          { socket.emit('err', '방을 찾을 수 없습니다'); return; }
    if (room.started)   { socket.emit('err', '게임이 이미 시작되었습니다'); return; }
    const team = autoTeam(room);
    room.players[socket.id] = { name, team, isTeacher: false, token: token || null };
    socket.join(code);
    socket.roomCode = code;
    socket.isTeacher = false;
    socket.emit('roomJoined', { code, team });
    io.to(code).emit('lobbyUpdate', getLobbyData(room));
  });

  // Reconnect: client sends this when socket.io reconnects mid-game
  socket.on('reconnectPlayer', ({ token, code }) => {
    if (!token || !code) return;
    const room = rooms[code];
    if (!room) return;

    // Cancel any pending cleanup for the old socket that had this token
    if (room._pendingDisconnects) {
      for (const [oldId, timer] of Object.entries(room._pendingDisconnects)) {
        const p = room.players[oldId] || (room.gameState && room.gameState.players[oldId]);
        const playerToken = room.players[oldId]?.token
          || (room.gameState?.players[oldId] ? room._tokens?.[oldId] : null);
        if (playerToken === token) {
          clearTimeout(timer);
          delete room._pendingDisconnects[oldId];

          // Re-key player under new socket.id
          if (room.players[oldId]) {
            room.players[socket.id] = room.players[oldId];
            delete room.players[oldId];
          }
          if (room.gameState?.players[oldId]) {
            const gp = room.gameState.players[oldId];
            gp.id = socket.id;
            room.gameState.players[socket.id] = gp;
            delete room.gameState.players[oldId];
            const pl = room.gameState.playerList.find(q => q.id === oldId);
            if (pl) pl.id = socket.id;
            for (const b of room.gameState.balls) { if (b.owner === oldId) b.owner = socket.id; }
          }
          break;
        }
      }
    }

    socket.roomCode = code;
    socket.isTeacher = room.players[socket.id]?.isTeacher || false;
    socket.join(code);

    if (room.gameState) {
      socket.emit('gameStart', packState(room.gameState));
    } else {
      socket.emit('lobbyUpdate', getLobbyData(room));
    }
  });

  socket.on('setTeam', ({ playerId, team }) => {
    const room = rooms[socket.roomCode];
    if (!room || !socket.isTeacher) return;
    if (room.players[playerId]) {
      room.players[playerId].team = team;
      io.to(socket.roomCode).emit('lobbyUpdate', getLobbyData(room));
    }
  });

  socket.on('startGame', ({ ballCount } = {}) => {
    const room = rooms[socket.roomCode];
    if (!room || !socket.isTeacher || room.started) return;
    const playerCount = Object.keys(room.players).length;
    if (playerCount < 2) { socket.emit('err', '최소 2명이 필요합니다'); return; }

    room.ballCount = Math.max(1, Math.min(5, parseInt(ballCount) || 1));
    room.started = true;
    let count = 3;
    io.to(socket.roomCode).emit('countdown', count);
    room.countdownTimer = setInterval(() => {
      count--;
      if (count > 0) {
        io.to(socket.roomCode).emit('countdown', count);
      } else {
        clearInterval(room.countdownTimer);
        room.countdownTimer = null;
        room.gameState = createGameState(room);
        io.to(socket.roomCode).emit('gameStart', packState(room.gameState));
        room.gameLoop = startGameLoop(room);
      }
    }, 1000);
  });

  socket.on('playerMove', ({ dx, dy }) => {
    const room = rooms[socket.roomCode];
    if (!room?.gameState || room.gameState.phase !== 'playing') return;
    const player = room.gameState.players[socket.id];
    if (!player) return;
    player.dx = Math.sign(dx);
    player.dy = Math.sign(dy);
  });

  socket.on('playerAction', ({ type, dx, dy }) => {
    const room = rooms[socket.roomCode];
    if (!room?.gameState || room.gameState.phase !== 'playing') return;
    const player = room.gameState.players[socket.id];
    if (!player) return;
    // Find ball owned by this player
    const ball = room.gameState.balls.find(b => b.owner === socket.id);
    if (!ball) return;

    // Direction: use pressed direction, fall back to facing direction
    const dirX = dx !== 0 ? Math.sign(dx) : player.facingX;
    const dirY = dy !== 0 ? Math.sign(dy) : player.facingY;
    const d    = norm(dirX, dirY);

    if (type === 'shoot') {
      ball.lastToucherId = socket.id;
      ball.vx = d.x * SHOOT_SPEED;
      ball.vy = d.y * SHOOT_SPEED;
      ball.x  = player.x + d.x * (PLAYER_RADIUS + BALL_RADIUS + 4);
      ball.y  = player.y + d.y * (PLAYER_RADIUS + BALL_RADIUS + 4);
      ball.owner = null;
      player.hasBall = false;
      player.releaseCd = RELEASE_CD;

    } else if (type === 'pass') {
      ball.lastToucherId = socket.id;

      // Find best teammate in pass direction
      let best = null, bestScore = -Infinity;
      for (const other of room.gameState.playerList) {
        if (other.id === socket.id || other.team !== player.team) continue;
        const toOther = norm(other.x - player.x, other.y - player.y);
        const dot     = d.x * toOther.x + d.y * toOther.y;
        if (dot > 0.15) {
          const score = dot * 2 - dist(player, other) / 350;
          if (score > bestScore) { bestScore = score; best = other; }
        }
      }

      const target = best
        ? { x: best.x, y: best.y }
        : { x: player.x + d.x * 250, y: player.y + d.y * 250 };

      const toTarget = norm(target.x - ball.x, target.y - ball.y);
      ball.vx = toTarget.x * PASS_SPEED;
      ball.vy = toTarget.y * PASS_SPEED;
      ball.x  = player.x + d.x * (PLAYER_RADIUS + BALL_RADIUS + 4);
      ball.y  = player.y + d.y * (PLAYER_RADIUS + BALL_RADIUS + 4);
      ball.owner = null;
      player.hasBall = false;
      player.releaseCd = RELEASE_CD;
    }
  });

  socket.on('resetRoom', () => {
    const room = rooms[socket.roomCode];
    if (!room || !socket.isTeacher) return;
    if (room.countdownTimer) { clearInterval(room.countdownTimer); room.countdownTimer = null; }
    if (room.gameLoop)       { stopGameLoop(room.gameLoop);       room.gameLoop = null; }
    room.started   = false;
    room.gameState = null;
    io.to(socket.roomCode).emit('backToLobby');
    io.to(socket.roomCode).emit('lobbyUpdate', getLobbyData(room));
  });

  socket.on('disconnect', () => {
    const code = socket.roomCode;
    if (!code || !rooms[code]) return;
    const room = rooms[code];

    // During an active game, delay cleanup to allow brief reconnects.
    // If the player reconnects within 8 s (reconnectPlayer event), the timer is cancelled.
    if (room.gameState && room.gameState.phase !== 'ended') {
      room._pendingDisconnects = room._pendingDisconnects || {};
      room._pendingDisconnects[socket.id] = setTimeout(() => {
        delete room._pendingDisconnects[socket.id];
        cleanupPlayer(code, socket.id);
      }, 8000);
    } else {
      cleanupPlayer(code, socket.id);
    }
  });
});

// ============================================================
// START SERVER
// ============================================================
server.listen(3000, () => {
  console.log('Server running on http://localhost:3000\n');
});
